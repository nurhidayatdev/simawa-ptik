<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$nama_lengkap = $_SESSION['nama_lengkap'];
$foto = $_SESSION['foto'];
$role = $_SESSION['role'];

if ($_SESSION['role'] === 'Mahasiswa' || $_SESSION['role'] === 'Bendahara' || $_SESSION['role'] === 'Ketua Tingkat') {
    include '../includes/alert_role.php'; 
    
    exit();
}



/* =====================
   AMBIL PERIODE AKTIF
   ===================== */
$q_periode = mysqli_query($koneksi, "SELECT id FROM periode WHERE status = 'aktif' LIMIT 1");
$periode = mysqli_fetch_assoc($q_periode);
$periode_id = $periode['id'];

$query_matkul = "
SELECT DISTINCT
    mk.id AS matkul_id,
    mk.nama_matkul
FROM krs k
JOIN mata_kuliah mk ON k.matkul_id = mk.id
WHERE k.periode_id = $periode_id
ORDER BY mk.nama_matkul ASC
";

$matkul = mysqli_query($koneksi, $query_matkul);

if (!$matkul) {
    die('Query matkul error: ' . mysqli_error($koneksi));
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $matkul_id = $_POST['matkul_id'];
    $pertemuan = $_POST['pertemuan'];
    $status    = $_POST['status'];


    // Ensure period is active
    if (!$periode_id) {
        die("Error: Tidak ada periode aktif. Harap setel periode aktif terlebih dahulu di menu Data Periode.");
    }

    foreach ($status as $mahasiswa_id => $st) {

        $query = "
        INSERT INTO absensi (mahasiswa_id, matkul_id, pertemuan, status, periode_id)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE status = ?
        ";

        $stmt = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param(
            $stmt,
            "iiisis",
            $mahasiswa_id,
            $matkul_id,
            $pertemuan,
            $st,
            $periode_id,
            $st
        );
        mysqli_stmt_execute($stmt);
    }
    // redirect agar tidak double submit
    header("Location: tambah_absensi.php?matkul_id=$matkul_id&pertemuan=$pertemuan&sukses=1");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  
    <title>Absensi - PTIK C 2024</title>
    <?php include '../includes/head.php'; ?>
    <style>
      

        .rotate-180 {
            transform: rotate(180deg);
        }

        /* Tambahan CSS untuk mobile menu */
        @media (max-width: 768px) {
            .mobile-menu-open {
                transform: translateX(0) !important;
            }
        }
    </style>
 
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body class="bg-slate-100">
    <?php include '../includes/menu_db.php'; ?>

    <main class="ml-0 lg:ml-48 pt-20 p-6 flex flex-col min-h-screen">
        <div class="bg-white rounded-lg border border-slate-200 p-6 flex-grow w-full">
            <!-- Modified this section for better mobile responsiveness -->
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                <h3 class="text-xl font-bold text-slate-800">Data Absensi</h3>
                <div class="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                    <form method="GET" class="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">



                        <a href="../views/absensi.php?matkul_id=<?= $_GET['matkul_id'] ?? ''; ?>&pertemuan=<?= $_GET['pertemuan'] ?? ''; ?>" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-800 text-center text-xs">
                            <button type="button">
                                Kembali
                            </button>
                        </a>
                    </form>






                </div>
            </div>
            <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">

                <select name="matkul_id" class="border p-2 rounded-lg text-xs" required onchange="this.form.submit()">
                    <option value="">-- Pilih Mata Kuliah --</option>
                    <?php while ($m = mysqli_fetch_assoc($matkul)): ?>
                        <option value="<?= $m['matkul_id'] ?>"
                            <?= (isset($_GET['matkul_id']) && $_GET['matkul_id'] == $m['matkul_id']) ? 'selected' : '' ?>>
                            <?= $m['nama_matkul'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>


                <select name="pertemuan" class="border p-2 rounded-lg text-xs" required onchange="this.form.submit()">
                    <option value="">-- Pertemuan --</option>
                    <?php for ($i = 1; $i <= 16; $i++): ?>
                        <option value="<?= $i ?>"
                            <?= ($_GET['pertemuan'] ?? '') == $i ? 'selected' : '' ?>>
                            Pertemuan <?= $i ?>
                        </option>
                    <?php endfor; ?>
                </select>

                <label class="sr-only">Filter</label>
                <select name="filter" onchange="this.form.submit()" class="border rounded px-4 py-2 text-xs">
                    <option value="all" <?= ($_GET['filter'] ?? 'all') == 'all' ? 'selected' : '' ?>>Semua</option>
                    <option value="Hadir" <?= ($_GET['filter'] ?? '') == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
                    <option value="Izin" <?= ($_GET['filter'] ?? '') == 'Izin' ? 'selected' : '' ?>>Izin</option>
                    <option value="Sakit" <?= ($_GET['filter'] ?? '') == 'Sakit' ? 'selected' : '' ?>>Sakit</option>
                    <option value="Alpha" <?= ($_GET['filter'] ?? '') == 'Alpha' ? 'selected' : '' ?>>Alpha</option>
                </select>
                <!-- tombol Tampilkan dihapus; pilihan akan auto-submit -->
            </form>

            <?php
            $matkul_id = null;
            $pertemuan = null;
            if (isset($_GET['matkul_id'], $_GET['pertemuan'])) :

                $matkul_id = (int) $_GET['matkul_id'];
                $pertemuan = (int) $_GET['pertemuan'];

                $filter = $_GET['filter'] ?? 'all';
                $filter = in_array($filter, ['all', 'Hadir', 'Izin', 'Sakit', 'Alpha']) ? $filter : 'all';

                $where_clause = '';
                if ($filter !== 'all') {
                    $where_clause = " AND a.status = '$filter'";
                }

                $query = "
        SELECT DISTINCT
            m.id AS mahasiswa_id,
            m.nim,
            m.nama_lengkap,
            a.status
        FROM krs k
        JOIN mahasiswa m ON k.mahasiswa_id = m.id
        LEFT JOIN absensi a 
            ON a.mahasiswa_id = m.id
            AND a.matkul_id = k.matkul_id
            AND a.pertemuan = ?
        WHERE k.matkul_id = ?
        AND k.periode_id = ?
        $where_clause
        ORDER BY m.nim ASC
    ";

                $stmt = mysqli_prepare($koneksi, $query);
                mysqli_stmt_bind_param($stmt, "iii", $pertemuan, $matkul_id, $periode_id);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
            ?>

                <!-- Rest of the content remains the same -->
                <div class="overflow-x-auto">
                    <form method="POST">
                        <input type="hidden" name="matkul_id" value="<?= $matkul_id ?>">
                        <input type="hidden" name="pertemuan" value="<?= $pertemuan ?>">

                        <table class="min-w-full divide-y divide-slate-200">
                            <thead class="bg-indigo-900">
                                <tr>
                                    <th class="px-3 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                                        No</th>
                                    <th class="hidden md:table-cell px-3 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                                        NIM</th>
                                    <th class="px-3 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                                        Nama Lengkap</th>
                                    <th class="px-3 py-3 text-left text-xs font-bold text-white uppercase tracking-wider">
                                        Status</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-slate-200">
                                <?php
                                $no = 1;
                                $id = 1;
                                while ($row = mysqli_fetch_assoc($result)) : ?>
                                    <tr class="<?= ($id++ % 2 == 0) ? 'bg-slate-100' : 'bg-white' ?> hover:bg-indigo-100">

                                        <td class="px-3 py-2 whitespace-nowrap text-xs text-slate-800"><?= $no++; ?></td>
                                        <td class="hidden md:table-cell px-3 py-2 whitespace-nowrap text-xs text-slate-800"><?= $row['nim']; ?></td>
                                        <td class="px-3 py-2 text-xs text-slate-800"><?= $row['nama_lengkap']; ?></td>
                                        <td class="px-3 py-2 whitespace-nowrap text-xs text-slate-800">
                                            <select name="status[<?= $row['mahasiswa_id'] ?>]"
                                                class="border p-1 rounded">
                                                <option value="Hadir" <?= $row['status'] == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
                                                <option value="Izin" <?= $row['status'] == 'Izin' ? 'selected' : '' ?>>Izin</option>
                                                <option value="Sakit" <?= $row['status'] == 'Sakit' ? 'selected' : '' ?>>Sakit</option>
                                                <option value="Alpha" <?= $row['status'] == 'Alpha' ? 'selected' : '' ?>>Alpha</option>
                                            </select>
                                        </td>


                                    </tr>
                                <?php endwhile; ?>
                            </tbody>

                        </table>
                        <div class="mt-8 pt-5 border-t border-slate-200 flex flex-col items-center">
                            <p class="text-[10px] text-slate-500 mb-4 italic">Silakan periksa kembali data kehadiran sebelum menekan tombol simpan.</p>
                            <button type="button" onclick="confirmSaveAbsensi()"
                                class="bg-indigo-900 hover:bg-indigo-800 text-white rounded-lg px-6 py-2.5 text-xs font-semibold shadow-lg shadow-indigo-900/20 transition-all active:scale-95 flex items-center">
                                <i class="fa fa-save mr-2"></i> Simpan Absensi
                            </button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
        <?php include '../includes/footer_db.php'; ?>
    </main>
    <?php include '../includes/script_db.php'; ?>
    <script>
      

        // SweetAlert for Saving Absensi
        function confirmSaveAbsensi() {
            Swal.fire({
                title: 'Simpan Absensi?',
                text: "Pastikan data kehadiran sudah sesuai.",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3730a3',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Ya, Simpan!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.querySelector('form[method="POST"]').submit();
                }
            });
        }

        // Show Success Alert
        <?php if (isset($_GET['sukses'])): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data absensi telah berhasil disimpan.',
                confirmButtonColor: '#3730a3'
            }).then(() => {
                // Remove parameter from URL
                const url = new URL(window.location);
                url.searchParams.delete('sukses');
                window.history.replaceState({}, document.title, url);
            });
        <?php endif; ?>
    </script>
</body>

</html>